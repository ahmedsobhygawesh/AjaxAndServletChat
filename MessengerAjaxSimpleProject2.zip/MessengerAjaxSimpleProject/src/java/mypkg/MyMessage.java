
package mypkg;


/**
 *
 * @author ahmedelgawesh
 */


public class MyMessage {
    private String messageContent;

    public MyMessage() 
    {
    }

    public MyMessage(String messageContent)
    {
        this.messageContent = messageContent;
    }

    /**
     * @return the senderName
     */
  

    /**
     * @param senderName the senderName to set
     */

    /**
     * @return the messageContent
     */
    public String getMessageContent() 
    {
        return messageContent;
    }

    /**
     * @param messageContent the messageContent to set
     */
    public void setMessageContent(String messageContent) 
    {
        this.messageContent = messageContent;
    }
    
}
